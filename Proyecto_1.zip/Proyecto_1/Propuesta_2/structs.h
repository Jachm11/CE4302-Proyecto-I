#ifndef PROPUESTA_2_STRUCTS_H
#define PROPUESTA_2_STRUCTS_H


#include <stdint.h>
#include <stdbool.h>



///Enums
typedef enum protocol_state_t
{
    Modified = 'M',
    Owned = 'O',
    Exclusive = 'E',
    Shared = 'S',
    Invalid = 'I'
} protocol_state;

typedef enum instruction_type_t
{
    Read = 'R',
    Write = 'W',
    Increment = 'I',
    Nop = 'N'
} instruction_type;


///Data structures
typedef struct SLL_node_t
{
    void* data;
    struct SLL_node* next;
} SLL_node;
typedef struct Queue_t
{
    SLL_node* first;
} Queue;
typedef struct LL_t
{
    SLL_node* first;
} LL;


///General Structs
typedef struct Instruction_t
{
    instruction_type type;
    int mem_addr;
} Instruction;

typedef struct PE_t
{
    int id;
    Queue* instructions;
    int reg;
    bool MT_done;
    bool process_ended;
} PE;

typedef struct cache_line_t
{
    int tag;
    bool is_valid;
    bool is_dirty;
    protocol_state state;
    int data;

} Cache_line;

typedef struct cache_t
{
    int id;
    Cache_line** lines;
} Cache;


///Messages structs
typedef struct MT_msg_t
{
    int cache_id;
    bool MT_request_type;
    int mem_addr;
    int data;
} MT_msg;


typedef struct interconnect_t
{
    Queue* messages;
} Interconnect;



#endif //PROPUESTA_2_STRUCTS_H